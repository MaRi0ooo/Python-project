# from random import *
# alf1: list = ["a","b", "c", "d", "e", "f", "l", "m", "n", "g", "h", "i", "j", "k",
#        "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
# mass = [[choice(alf1) for i in range(11)] for i in range(3)]
# for i in range(len(mass)):
#     for j in range(len(mass[i])):
#         print(mass[i][j], end=" ")
#     print("")
# for g in range(len(mass)*len(mass[0])):
#     for j in range(len(mass)):
#         for i in range(len(mass[j])):
#             if len(mass[j]) - 1 == i:
#                 if j < len(mass) - 1:
#                     if mass[j][i] < mass[j+1][0]:
#                         mass[j][i], mass[mass+1][0] = mass[j+1][0], mass[j][i]
#



